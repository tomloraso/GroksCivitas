# Quality Gate Eval

A change is acceptable only if:

1. Backend lint/type/tests pass.
2. Web lint/type/tests/build pass.
3. Boundary test passes.
4. Docs and `docs/index.md` are updated for behavior changes.

# Agent Integration

This directory holds reusable artifacts for agent-assisted development.

- `prompts/`: task and review prompt templates.
- `evals/`: checks used to evaluate agent-generated changes.

Use these alongside `AGENTS.md` and `.agents/*` guides.

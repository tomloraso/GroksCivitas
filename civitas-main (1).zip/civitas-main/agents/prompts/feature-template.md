# Feature Prompt Template

Goal:

Constraints:

Architecture placement:

Acceptance criteria:

Verification commands:

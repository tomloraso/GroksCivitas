# Civitas Docs

## Start here

1. [Project Brief](../.planning/project-brief.md)
2. [Architecture](./architecture.md)
3. [Contributing](./contributing.md)
4. [Architecture Principles](./architecture/principles.md)
5. [Boundaries](./architecture/boundaries.md)
6. [Backend Conventions](./architecture/backend-conventions.md)
7. [Frontend Conventions](./architecture/frontend-conventions.md)
8. [Testing Strategy](./architecture/testing-strategy.md)
9. [ADR 0001: Architecture](./adr/0001-architecture.md)
10. [Local Development Runbook](./runbooks/local-development.md)


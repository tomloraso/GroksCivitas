# Architecture

Civitas uses an apps-first monorepo with a hexagonal backend and React web app.

- `apps/backend`: Python API and CLI with domain/application/infrastructure boundaries and bootstrap composition.
- `apps/web`: React frontend consuming backend contracts.
- `packages`: optional shared libraries for Python/TypeScript.

Read these pages before changing structure:

- `docs/architecture/principles.md`
- `docs/architecture/boundaries.md`
- `docs/architecture/backend-conventions.md`
- `docs/architecture/frontend-conventions.md`
- `docs/architecture/testing-strategy.md`

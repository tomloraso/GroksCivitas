# Contributing

1. Read `AGENTS.md`, `docs/architecture.md`, and the relevant conventions page (`backend-conventions.md` or `frontend-conventions.md`).
2. Write tests first for behavior changes.
3. Keep imports aligned with boundary rules.
4. Run `make lint` and `make test` before opening a PR.
5. Update docs and `docs/index.md` when behavior changes.

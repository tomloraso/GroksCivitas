# Architecture Guardrails

Before any non-trivial change, read `docs/architecture.md`.
For backend feature implementation details, read `docs/architecture/backend-conventions.md`.
For frontend feature implementation details, read `docs/architecture/frontend-conventions.md`.

## Package ownership

- `apps/backend/src/civitas/domain`: business rules and entities.
- `apps/backend/src/civitas/application`: use-cases, orchestration, and ports.
- `apps/backend/src/civitas/infrastructure`: persistence and external integrations.
- `apps/backend/src/civitas/api` and `cli`: transport entrypoints only.
- `apps/backend/src/civitas/bootstrap`: dependency composition/wiring.
- `apps/web/src/api`: frontend API clients and contract types only.
- `apps/web/src/features`: feature-level UI/state logic.
- `apps/web/src/shared`: reusable UI primitives and pure utilities.

## Dependency direction (non-negotiable)

- Domain must not import `application`, `infrastructure`, `api`, `cli`, or `bootstrap`.
- Application may import domain but must not import infrastructure or transport layers.
- Infrastructure implements application/domain ports.
- API/CLI depend on application contracts and bootstrap wiring.
- In web, components/pages/features depend on typed API modules; only `apps/web/src/api/*` performs network IO.
- In web, frontend contract types are derived from backend OpenAPI (`src/api/generated-types.ts` -> `src/api/types.ts`).

## Utility ownership split

- Domain-owned helpers: `domain/shared/helpers`.
- Application-owned helpers: `application/shared/utils`.
- Do not add a global `utils` package at root.

## Import style

- Use explicit leaf imports.
- No barrel imports (`__init__.py` re-export chains).
- Keep one canonical import path per concept.

## Models, Contracts, Ports

- Domain models live in `domain/<feature>` and carry business invariants.
- Application ports live in `application/<feature>/ports` as Protocols.
- API request/response schemas live only in `api/schemas`.
- Do not return API schemas from application or infrastructure layers.
- Keep mapping ownership explicit:
  - API maps wire schemas <-> app/domain contracts.
  - Infrastructure maps DB/external payloads <-> app/domain contracts.

## Enforcement

- `apps/backend/tests/unit/test_import_boundaries.py` verifies layer boundaries.
- `ruff` tidy-import rules backstop banned imports.
- `apps/web/eslint.config.js` enforces frontend contract/import/network guardrails.


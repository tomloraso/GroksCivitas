"""Application bootstrap and dependency wiring."""

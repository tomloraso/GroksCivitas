# TypeScript Shared Packages

Place reusable frontend/shared TS modules here when more than one app needs them.

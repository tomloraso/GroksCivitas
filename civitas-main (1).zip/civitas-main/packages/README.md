# Packages

Optional shared libraries across apps.

- `packages/python`: shared Python packages.
- `packages/ts`: shared TypeScript packages.

Prefer starting without shared packages; extract only after concrete reuse appears.

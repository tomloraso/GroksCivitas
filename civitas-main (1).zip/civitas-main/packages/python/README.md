# Python Shared Packages

Place reusable backend libraries here when more than one app needs them.
